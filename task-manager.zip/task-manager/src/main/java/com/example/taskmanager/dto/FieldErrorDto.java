package com.example.taskmanager.dto;

public record FieldErrorDto(String field, String message) {}