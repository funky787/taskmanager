package com.example.taskmanager.model;

public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    DONE
}